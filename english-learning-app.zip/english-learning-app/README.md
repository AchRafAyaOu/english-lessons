# تطبيق تعلم اللغة الإنجليزية | English Learning App

منصة تفاعلية مصممة خصيصًا للمتحدثين باللغة العربية لتعلم اللغة الإنجليزية.

An interactive platform specifically designed for Arabic speakers to learn English.

---

## المميزات | Features

- **واجهة ثنائية اللغة** — دعم كامل للغتين العربية والإنجليزية  
  Bilingual Interface — Full Arabic/English support
- **دروس منظمة** — مستويات مبتدئ، متوسط، متقدم  
  Structured Lessons — Beginner, Intermediate, Advanced levels
- **اختبارات تفاعلية** — تقييم فهمك بعد كل درس  
  Interactive Quizzes — Test your understanding after each lesson
- **تتبع التقدم** — احفظ تقدمك في كل درس  
  Progress Tracking — Save your progress across all lessons
- **لوحة تحكم المشرف** — إدارة المستخدمين والمحتوى  
  Admin Dashboard — Manage users and lesson content

---

## التقنيات المستخدمة | Tech Stack

| Layer      | Technology                        |
|------------|-----------------------------------|
| Backend    | Python 3.11, Flask, SQLAlchemy    |
| Frontend   | HTML5, Bootstrap 5, JavaScript    |
| Database   | PostgreSQL                        |
| Auth       | Flask-Login, Werkzeug             |
| Hosting    | Gunicorn (WSGI)                   |

---

## هيكل المشروع | Project Structure

```
english-learning-app/
├── app.py                        # Flask app & DB config
├── main.py                       # Entry point
├── models.py                     # Database models
├── routes.py                     # All routes & logic
├── requirements.txt              # Python dependencies
├── Procfile                      # Deployment command
├── .gitignore
├── data/
│   └── lessons.json              # Bilingual lesson content
├── static/
│   ├── css/style.css
│   ├── img/logo.svg
│   └── js/main.js
└── templates/
    ├── layout.html               # Base template (navbar, footer)
    ├── index.html                # Home page
    ├── lessons.html              # Lessons listing
    ├── lesson.html               # Individual lesson + quiz
    ├── login.html                # Login & Register
    ├── about.html                # About page
    ├── error.html                # 404/500 error page
    ├── admin_dashboard.html      # Admin panel
    └── admin_user_progress.html  # Per-user progress (admin)
```

---

## التثبيت المحلي | Local Installation

### المتطلبات | Requirements
- Python 3.10+
- PostgreSQL

### الخطوات | Steps

```bash
# 1. استنساخ المستودع | Clone the repo
git clone https://github.com/yourusername/english-learning-app.git
cd english-learning-app

# 2. إنشاء بيئة افتراضية | Create virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. تثبيت الحزم | Install dependencies
pip install -r requirements.txt

# 4. متغيرات البيئة | Set environment variables
export DATABASE_URL="postgresql://user:password@localhost:5432/englishdb"
export SESSION_SECRET="your-secret-key-here"

# 5. تشغيل التطبيق | Run the app
gunicorn --bind 0.0.0.0:5000 --reload main:app
```

افتح المتصفح على: `http://localhost:5000`

---

## إعداد حساب المشرف | Admin Setup

بعد تشغيل التطبيق، افتح الرابط:

```
http://localhost:5000/setup_admin
```

سيتم إنشاء حساب مشرف بالبيانات التالية:
- **اسم المستخدم:** `admin`
- **كلمة المرور:** `admin123`

> ⚠️ غيّر كلمة المرور فور تسجيل الدخول لأول مرة.

---

## النشر على Heroku | Deploy to Heroku

```bash
heroku create your-app-name
heroku addons:create heroku-postgresql:mini
heroku config:set SESSION_SECRET="your-secret-key"
git push heroku main
```

---

## الترخيص | License

MIT License — حر الاستخدام والتعديل والتوزيع.
