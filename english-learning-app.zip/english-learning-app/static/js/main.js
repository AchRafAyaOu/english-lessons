/**
 * Main JavaScript file for the English Learning Application
 */

document.addEventListener('DOMContentLoaded', function() {
    
    // Handle flash messages auto-dismiss
    const flashMessages = document.querySelectorAll('.alert-dismissible');
    flashMessages.forEach(message => {
        setTimeout(() => {
            const closeButton = message.querySelector('.btn-close');
            if (closeButton) {
                closeButton.click();
            }
        }, 5000); // Auto-dismiss after 5 seconds
    });

    // Language switcher visual indication
    const languageDropdown = document.getElementById('languageDropdown');
    if (languageDropdown) {
        const currentLanguage = document.documentElement.lang;
        if (currentLanguage === 'ar') {
            languageDropdown.innerHTML = '<i class="fas fa-globe me-1"></i> العربية';
        } else {
            languageDropdown.innerHTML = '<i class="fas fa-globe me-1"></i> English';
        }
    }

    // Add active class to current navigation item
    const currentLocation = window.location.pathname;
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    
    navLinks.forEach(link => {
        const linkPath = link.getAttribute('href');
        if (linkPath && currentLocation.includes(linkPath) && linkPath !== '/') {
            link.classList.add('active');
        } else if (linkPath === '/' && currentLocation === '/') {
            link.classList.add('active');
        }
    });

    // Bootstrap tooltip initialization (if needed)
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    
    forms.forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });

    // Back to top button
    const backToTopButton = document.getElementById('back-to-top');
    
    if (backToTopButton) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                backToTopButton.classList.add('show');
            } else {
                backToTopButton.classList.remove('show');
            }
        });
        
        backToTopButton.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // Language-specific adjustments
    const htmlElement = document.documentElement;
    const languageCode = htmlElement.lang;
    
    if (languageCode === 'ar') {
        // Adjust any specific CSS or attributes for Arabic
        document.body.classList.add('arabic-font');
    }
});

/**
 * Updates the user interface based on language selection
 * @param {string} language - The language code ('en' or 'ar')
 */
function updateUILanguage(language) {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    
    if (language === 'ar') {
        document.body.classList.add('arabic-font');
    } else {
        document.body.classList.remove('arabic-font');
    }
}

/**
 * Shows a notification message to the user
 * @param {string} message - The message to display
 * @param {string} type - The message type (success, warning, error, info)
 * @param {number} duration - Duration in milliseconds to show the notification
 */
function showNotification(message, type = 'info', duration = 3000) {
    const notificationArea = document.getElementById('notification-area');
    
    if (!notificationArea) {
        // Create notification area if it doesn't exist
        const newNotificationArea = document.createElement('div');
        newNotificationArea.id = 'notification-area';
        newNotificationArea.className = 'position-fixed top-0 end-0 p-3';
        newNotificationArea.style.zIndex = '1050';
        document.body.appendChild(newNotificationArea);
    }
    
    const id = 'notification-' + Date.now();
    const notification = document.createElement('div');
    notification.className = `toast align-items-center text-white bg-${type} border-0`;
    notification.setAttribute('role', 'alert');
    notification.setAttribute('aria-live', 'assertive');
    notification.setAttribute('aria-atomic', 'true');
    notification.id = id;
    
    notification.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    document.getElementById('notification-area').appendChild(notification);
    
    const toast = new bootstrap.Toast(notification, { 
        autohide: true,
        delay: duration
    });
    
    toast.show();
    
    // Remove the element after it's hidden
    notification.addEventListener('hidden.bs.toast', function() {
        notification.remove();
    });
}
