import json
import os
from flask import render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from app import app, db
from models import User, UserProgress

# Load lessons data
def load_lessons():
    try:
        with open('data/lessons.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return {"lessons": []}


# Check if user is logged in
def is_logged_in():
    return 'user_id' in session


# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login to access this page', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


# Home page route
@app.route('/')
def index():
    language = request.args.get('lang', session.get('language', 'en'))
    session['language'] = language
    return render_template('index.html', language=language, User=User)


# About page route
@app.route('/about')
def about():
    language = session.get('language', 'en')
    return render_template('about.html', language=language, User=User)


# Lessons page route
@app.route('/lessons')
def lessons():
    language = session.get('language', 'en')
    lessons_data = load_lessons()
    
    user_progress = {}
    if is_logged_in():
        user_id = session['user_id']
        progress_records = UserProgress.query.filter_by(user_id=user_id).all()
        
        for record in progress_records:
            user_progress[record.lesson_id] = {
                'completed': record.completed,
                'score': record.score
            }
    
    return render_template('lessons.html', 
                           lessons=lessons_data['lessons'], 
                           user_progress=user_progress,
                           language=language,
                           User=User)


# Specific lesson route
@app.route('/lesson/<int:lesson_id>')
def lesson(lesson_id):
    language = session.get('language', 'en')
    lessons_data = load_lessons()
    
    # Find the specific lesson
    selected_lesson = None
    for lesson in lessons_data['lessons']:
        if lesson['id'] == lesson_id:
            selected_lesson = lesson
            break
    
    if selected_lesson is None:
        flash('Lesson not found', 'danger')
        return redirect(url_for('lessons'))
    
    # Get user progress for this lesson if logged in
    user_progress = None
    if is_logged_in():
        user_id = session['user_id']
        progress = UserProgress.query.filter_by(user_id=user_id, lesson_id=lesson_id).first()
        
        if progress:
            user_progress = {
                'completed': progress.completed,
                'score': progress.score
            }
        else:
            # Create a new progress record if it doesn't exist
            new_progress = UserProgress(user_id=user_id, lesson_id=lesson_id)
            db.session.add(new_progress)
            db.session.commit()
            user_progress = {
                'completed': False,
                'score': 0
            }
    
    return render_template('lesson.html', 
                           lesson=selected_lesson,
                           user_progress=user_progress,
                           language=language,
                           User=User)


# Register route
@app.route('/register', methods=['GET', 'POST'])
def register():
    language = session.get('language', 'en')
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Check if user exists
        existing_user = User.query.filter_by(username=username).first()
        existing_email = User.query.filter_by(email=email).first()
        
        if existing_user:
            flash('Username already exists', 'danger')
            return redirect(url_for('register'))
        
        if existing_email:
            flash('Email already in use', 'danger')
            return redirect(url_for('register'))
        
        # Create new user
        new_user = User(
            username=username,
            email=email,
            language_preference=language
        )
        new_user.set_password(password)
        
        db.session.add(new_user)
        db.session.commit()
        
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('login.html', action='register', language=language, User=User)


# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    language = session.get('language', 'en')
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Find user
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['language'] = user.language_preference
            
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html', action='login', language=language, User=User)


# Logout route
@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))


# Update lesson progress
@app.route('/update_progress', methods=['POST'])
@login_required
def update_progress():
    if not request.is_json:
        return jsonify({'error': 'Request must be JSON'}), 400
    
    data = request.get_json()
    lesson_id = data.get('lesson_id')
    completed = data.get('completed', False)
    score = data.get('score', 0)
    
    if not lesson_id:
        return jsonify({'error': 'Lesson ID is required'}), 400
    
    user_id = session['user_id']
    
    # Find existing progress or create new one
    progress = UserProgress.query.filter_by(user_id=user_id, lesson_id=lesson_id).first()
    
    if progress:
        progress.completed = completed
        progress.score = score
    else:
        progress = UserProgress(
            user_id=user_id,
            lesson_id=lesson_id,
            completed=completed,
            score=score
        )
        db.session.add(progress)
    
    db.session.commit()
    
    return jsonify({'success': True})


# Change language preference
@app.route('/change_language/<lang>')
def change_language(lang):
    # Store language preference in session
    session['language'] = lang
    
    # Update user preference if logged in
    if is_logged_in():
        user_id = session['user_id']
        user = User.query.get(user_id)
        if user:
            user.language_preference = lang
            db.session.commit()
    
    # Redirect back to referring page or home
    return redirect(request.referrer or url_for('index'))


# Admin dashboard
@app.route('/admin')
@login_required
def admin_dashboard():
    language = session.get('language', 'en')
    
    # Check if user is admin
    user_id = session['user_id']
    user = User.query.get(user_id)
    
    if not user or not user.is_admin:
        flash('You do not have permission to access this page', 'danger')
        return redirect(url_for('index'))
    
    # Get user statistics
    user_count = User.query.count()
    completed_lessons = UserProgress.query.filter_by(completed=True).count()
    
    # Get lessons data
    lessons_data = load_lessons()
    total_lessons = len(lessons_data['lessons'])
    
    # Get all users
    users = User.query.all()
    
    return render_template('admin_dashboard.html',
                           language=language,
                           user_count=user_count,
                           completed_lessons=completed_lessons,
                           total_lessons=total_lessons,
                           users=users,
                           lessons=lessons_data['lessons'],
                           User=User)


# Make user admin
@app.route('/admin/make_admin/<int:user_id>')
@login_required
def make_admin(user_id):
    language = session.get('language', 'en')
    
    # Check if current user is admin
    current_user_id = session['user_id']
    current_user = User.query.get(current_user_id)
    
    if not current_user or not current_user.is_admin:
        flash('You do not have permission to perform this action', 'danger')
        return redirect(url_for('index'))
    
    # Get user to make admin
    user = User.query.get(user_id)
    
    if not user:
        flash('User not found', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    # Make user admin
    user.is_admin = True
    db.session.commit()
    
    flash('User has been granted admin privileges', 'success')
    return redirect(url_for('admin_dashboard'))


# View user progress (admin)
@app.route('/admin/user/<int:user_id>/progress')
@login_required
def admin_view_user_progress(user_id):
    language = session.get('language', 'en')
    
    # Check if current user is admin
    current_user_id = session['user_id']
    current_user = User.query.get(current_user_id)
    
    if not current_user or not current_user.is_admin:
        flash('You do not have permission to access this page', 'danger')
        return redirect(url_for('index'))
    
    # Get user
    user = User.query.get(user_id)
    
    if not user:
        flash('User not found', 'danger')
        return redirect(url_for('admin_dashboard'))
    
    # Get user progress
    progress_records = UserProgress.query.filter_by(user_id=user_id).all()
    
    # Get lessons data
    lessons_data = load_lessons()
    
    # Create a mapping of lesson_id to lesson details
    lesson_mapping = {}
    for lesson in lessons_data['lessons']:
        lesson_mapping[lesson['id']] = lesson
    
    return render_template('admin_user_progress.html',
                          language=language,
                          user=user,
                          progress_records=progress_records,
                          lesson_mapping=lesson_mapping,
                          User=User)


# Create initial admin user
@app.route('/setup_admin')
def setup_admin():
    # Check if any users exist
    user_count = User.query.count()
    
    if user_count > 0:
        admin_exists = User.query.filter_by(is_admin=True).first()
        if admin_exists:
            flash('Admin user already exists', 'info')
            return redirect(url_for('index'))
    
    # Create admin user
    admin_user = User(
        username='admin',
        email='admin@example.com',
        language_preference='en',
        is_admin=True
    )
    admin_user.set_password('admin123')
    
    db.session.add(admin_user)
    db.session.commit()
    
    flash('Admin user created successfully. Username: admin, Password: admin123', 'success')
    return redirect(url_for('login'))


# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    language = session.get('language', 'en')
    return render_template('error.html', 
                           error_code=404, 
                           error_message="Page not found", 
                           language=language,
                           User=User), 404


@app.errorhandler(500)
def server_error(e):
    language = session.get('language', 'en')
    return render_template('error.html', 
                           error_code=500, 
                           error_message="Internal server error", 
                           language=language,
                           User=User), 500


# Ensure the data directory exists
def create_data_directory():
    os.makedirs('data', exist_ok=True)
    
    # Create lessons.json if it doesn't exist
    if not os.path.exists('data/lessons.json'):
        default_lessons = {
            "lessons": [
                {
                    "id": 1,
                    "level": "Beginner",
                    "title": {
                        "en": "Basic Greetings",
                        "ar": "التحيات الأساسية"
                    },
                    "description": {
                        "en": "Learn basic English greetings and introductions.",
                        "ar": "تعلم التحيات والمقدمات الأساسية باللغة الإنجليزية."
                    },
                    "content": {
                        "en": [
                            {"phrase": "Hello", "translation": "مرحبا"},
                            {"phrase": "Good morning", "translation": "صباح الخير"},
                            {"phrase": "Good afternoon", "translation": "مساء الخير"},
                            {"phrase": "Good evening", "translation": "مساء الخير"},
                            {"phrase": "How are you?", "translation": "كيف حالك؟"},
                            {"phrase": "I'm fine, thank you", "translation": "أنا بخير، شكراً"},
                            {"phrase": "What's your name?", "translation": "ما اسمك؟"},
                            {"phrase": "My name is...", "translation": "اسمي..."},
                            {"phrase": "Nice to meet you", "translation": "تشرفت بمعرفتك"},
                            {"phrase": "Goodbye", "translation": "وداعاً"}
                        ],
                        "ar": [
                            {"phrase": "مرحبا", "translation": "Hello"},
                            {"phrase": "صباح الخير", "translation": "Good morning"},
                            {"phrase": "مساء الخير", "translation": "Good afternoon"},
                            {"phrase": "مساء الخير", "translation": "Good evening"},
                            {"phrase": "كيف حالك؟", "translation": "How are you?"},
                            {"phrase": "أنا بخير، شكراً", "translation": "I'm fine, thank you"},
                            {"phrase": "ما اسمك؟", "translation": "What's your name?"},
                            {"phrase": "اسمي...", "translation": "My name is..."},
                            {"phrase": "تشرفت بمعرفتك", "translation": "Nice to meet you"},
                            {"phrase": "وداعاً", "translation": "Goodbye"}
                        ]
                    },
                    "quiz": [
                        {
                            "question": {
                                "en": "How do you say 'Good morning' in English?",
                                "ar": "كيف تقول 'صباح الخير' باللغة الإنجليزية؟"
                            },
                            "options": [
                                {"en": "Good night", "ar": "ليلة سعيدة"},
                                {"en": "Good afternoon", "ar": "مساء الخير"},
                                {"en": "Good morning", "ar": "صباح الخير"},
                                {"en": "Hello", "ar": "مرحبا"}
                            ],
                            "correct": 2
                        }
                    ]
                },
                {
                    "id": 2,
                    "level": "Beginner",
                    "title": {
                        "en": "Numbers and Counting",
                        "ar": "الأرقام والعد"
                    },
                    "description": {
                        "en": "Learn numbers from 1-20 and basic counting in English.",
                        "ar": "تعلم الأرقام من 1-20 والعد الأساسي باللغة الإنجليزية."
                    },
                    "content": {
                        "en": [
                            {"phrase": "One", "translation": "واحد"},
                            {"phrase": "Two", "translation": "اثنان"},
                            {"phrase": "Three", "translation": "ثلاثة"},
                            {"phrase": "Four", "translation": "أربعة"},
                            {"phrase": "Five", "translation": "خمسة"},
                            {"phrase": "Six", "translation": "ستة"},
                            {"phrase": "Seven", "translation": "سبعة"},
                            {"phrase": "Eight", "translation": "ثمانية"},
                            {"phrase": "Nine", "translation": "تسعة"},
                            {"phrase": "Ten", "translation": "عشرة"}
                        ],
                        "ar": [
                            {"phrase": "واحد", "translation": "One"},
                            {"phrase": "اثنان", "translation": "Two"},
                            {"phrase": "ثلاثة", "translation": "Three"},
                            {"phrase": "أربعة", "translation": "Four"},
                            {"phrase": "خمسة", "translation": "Five"},
                            {"phrase": "ستة", "translation": "Six"},
                            {"phrase": "سبعة", "translation": "Seven"},
                            {"phrase": "ثمانية", "translation": "Eight"},
                            {"phrase": "تسعة", "translation": "Nine"},
                            {"phrase": "عشرة", "translation": "Ten"}
                        ]
                    },
                    "quiz": [
                        {
                            "question": {
                                "en": "What is the English word for the number 5?",
                                "ar": "ما هي الكلمة الإنجليزية للرقم 5؟"
                            },
                            "options": [
                                {"en": "Three", "ar": "ثلاثة"},
                                {"en": "Four", "ar": "أربعة"},
                                {"en": "Five", "ar": "خمسة"},
                                {"en": "Six", "ar": "ستة"}
                            ],
                            "correct": 2
                        }
                    ]
                },
                {
                    "id": 3,
                    "level": "Intermediate",
                    "title": {
                        "en": "Common Phrases",
                        "ar": "العبارات الشائعة"
                    },
                    "description": {
                        "en": "Learn everyday phrases used in English conversations.",
                        "ar": "تعلم العبارات اليومية المستخدمة في المحادثات الإنجليزية."
                    },
                    "content": {
                        "en": [
                            {"phrase": "How can I help you?", "translation": "كيف يمكنني مساعدتك؟"},
                            {"phrase": "I don't understand", "translation": "أنا لا أفهم"},
                            {"phrase": "Could you repeat that, please?", "translation": "هل يمكنك إعادة ذلك من فضلك؟"},
                            {"phrase": "Where is the bathroom?", "translation": "أين هو الحمام؟"},
                            {"phrase": "How much does this cost?", "translation": "كم تكلفة هذا؟"},
                            {"phrase": "I would like to order", "translation": "أود أن أطلب"},
                            {"phrase": "Do you speak Arabic?", "translation": "هل تتحدث العربية؟"},
                            {"phrase": "I speak a little English", "translation": "أتحدث الإنجليزية قليلاً"},
                            {"phrase": "Thank you very much", "translation": "شكراً جزيلاً"},
                            {"phrase": "You're welcome", "translation": "على الرحب والسعة"}
                        ],
                        "ar": [
                            {"phrase": "كيف يمكنني مساعدتك؟", "translation": "How can I help you?"},
                            {"phrase": "أنا لا أفهم", "translation": "I don't understand"},
                            {"phrase": "هل يمكنك إعادة ذلك من فضلك؟", "translation": "Could you repeat that, please?"},
                            {"phrase": "أين هو الحمام؟", "translation": "Where is the bathroom?"},
                            {"phrase": "كم تكلفة هذا؟", "translation": "How much does this cost?"},
                            {"phrase": "أود أن أطلب", "translation": "I would like to order"},
                            {"phrase": "هل تتحدث العربية؟", "translation": "Do you speak Arabic?"},
                            {"phrase": "أتحدث الإنجليزية قليلاً", "translation": "I speak a little English"},
                            {"phrase": "شكراً جزيلاً", "translation": "Thank you very much"},
                            {"phrase": "على الرحب والسعة", "translation": "You're welcome"}
                        ]
                    },
                    "quiz": [
                        {
                            "question": {
                                "en": "How would you ask for the cost of an item in English?",
                                "ar": "كيف تسأل عن تكلفة شيء ما باللغة الإنجليزية؟"
                            },
                            "options": [
                                {"en": "Where is this?", "ar": "أين هذا؟"},
                                {"en": "How much does this cost?", "ar": "كم تكلفة هذا؟"},
                                {"en": "What time is it?", "ar": "كم الساعة؟"},
                                {"en": "I don't understand", "ar": "أنا لا أفهم"}
                            ],
                            "correct": 1
                        }
                    ]
                }
            ]
        }
        
        with open('data/lessons.json', 'w', encoding='utf-8') as f:
            json.dump(default_lessons, f, ensure_ascii=False, indent=2)
